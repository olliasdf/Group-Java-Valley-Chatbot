# apache-opennlp-chatbot-example
Custom chat bot in Java using Apache OpenNLP

  This code is part of article from itsallbinary.com. Get detailed explanation of this example [in this article](http://itsallbinary.com/create-your-own-chat-bot-in-java-using-apache-opennlp-artificial-intelligence-natural-language-processing/).
  
  http://itsallbinary.com/create-your-own-chat-bot-in-java-using-apache-opennlp-artificial-intelligence-natural-language-processing/
